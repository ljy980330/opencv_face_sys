#ifndef CAMERWIDGET_H
#define CAMERWIDGET_H

#include <QWidget>
#include "includes.h"

namespace Ui {
class CamerWidget;
}

class CamerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CamerWidget(QWidget *parent = 0);
    ~CamerWidget();

    int weather_widget_startX,weather_widget_startY;
    int sysinfo_widget_startX,sysinfo_widget_startY;

    void weather_now_updata(struct Weather_Now_Data weather_now_data);

    QImage Mat2QImage(cv::Mat cvImg);

public slots:
    void get_camer_info(struct CamerInfo_Data camer_info_data);

    void rtc_updata(struct RTC_Data rtc_data);

    void get_weather_info(struct Weather_Data weather_data);

protected:
    void mousePressEvent(QMouseEvent *event);

signals:
    void mousePress_sig(int flag);

private:
    Ui::CamerWidget *ui;
};

#endif // CAMERWIDGET_H
