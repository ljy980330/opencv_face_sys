#include "camerinfo_thread.h"

CamerInfo_thread::CamerInfo_thread(QObject *parent) :
    QThread(parent)
{
    stopped = true;

    QFile came_file(VIDEO_NAME);
    if(came_file.open(QFile::ReadOnly))
    {
        came_file.close();
        opencam();
    }
    else
    {
        qDebug() << "No device named " << VIDEO_NAME;
    }
}

CamerInfo_thread::~CamerInfo_thread()
{
    stopped = true;

    if (capture.isOpened())
    {
        capture.release();
    }
}

void CamerInfo_thread::run()
{
    stopped = false;

    while(stopped == false)
    {
        if (capture.isOpened())
        {
            camer_info_data.fps = capture.get(CV_CAP_PROP_FPS); //get camer fps
            //qDebug() << rate;
            capture >> frame;
            if (!frame.empty())
            {
                camer_info_data.frame = frame;
                emit camer_info_sig(camer_info_data);
            }
        }
        else
        {
            qDebug() << VIDEO_NAME << " is not open...\nexit thread...";
            break;
        }
    }
}

void CamerInfo_thread::stop()
{
    stopped = true;
}

void CamerInfo_thread::opencam()
{
    if (capture.isOpened())
            capture.release();     //decide if capture is already opened; if so,close it
    capture.open(VIDEO_NAME);           //open the default camera
}
