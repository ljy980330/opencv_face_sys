#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include "includes.h"

// include all Widget headers
#include "welcomewidget.h"
#include "camerwidget.h"
#include "weatherwidget.h"

// include all thread headers
#include "sysinfo_thread.h"

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

protected:
    void paintEvent(QPaintEvent *); //界面重绘事件
    void resizeEvent(QResizeEvent *); //窗体大小改变事件

    QPixmap BackGroudImage; //背景图片
    QFont font; //字体

signals:
    void camer_widget_stop_sig(bool flag);

protected slots:
    void camer_widget_setup();
    void camer_widget_weather_press(bool flag);

    void weather_widget_close();

private:
    Ui::MainWidget *ui;

    // ui pointer
    WelcomeWidget *welcome_widget_ui;
    CamerWidget *camer_widget_ui;
    WeatherWidget *weather_widget_ui;

    // thread pointer
    SysInfo_thread *sys_info_thread;
};

#endif // MAINWIDGET_H
