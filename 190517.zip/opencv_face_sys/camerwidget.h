#ifndef CAMERWIDGET_H
#define CAMERWIDGET_H

#include <QWidget>
#include "includes.h"

#include "camerwidget_rtc_thread.h"
#include "camerwidget_camer_thread.h"

namespace Ui {
class CamerWidget;
}

class CamerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CamerWidget(QWidget *parent = 0);
    ~CamerWidget();

    QString url_weather_now;
    //QString url_weather_life;

    QTimer *weather_timer;

    struct Weather_Now_Data weather_now_data;

    void json_analysis_now(QByteArray data);   //解析json格式现在天气

public slots:
    void camer_widget_stop(bool flag);

    void get_cpu_info(struct CpuInfo_data cpu_info_data);
    void get_mem_info(struct MemInfo_data mem_info_data);
    void get_disk_info(struct DiskInfo_data disk_info_data);

protected:
    void mousePressEvent(QMouseEvent *event);

signals:
    void mousePress_sig(bool flag);

private slots:
    void finishedSlot(QNetworkReply*);

    void weather_get();
    void weather_updata();
    void rtc_updata(QDateTime date_time);

    void camer_updata(struct CamerInfo_data camer_info_data);

private:
    Ui::CamerWidget *ui;

    QNetworkAccessManager *m_NetManger;
    QNetworkReply* m_Reply;

    CamerWidget_rtc_thread *camerwidget_rtc_thread;
    CamerWidget_camer_thread *camerwidget_camer_thread;
};

#endif // CAMERWIDGET_H
