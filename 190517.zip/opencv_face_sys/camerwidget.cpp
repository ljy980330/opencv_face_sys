#include "camerwidget.h"
#include "ui_camerwidget.h"

CamerWidget::CamerWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CamerWidget)
{
    ui->setupUi(this);

    this->resize(800,480);

    //支持Qt中文字库
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));

    //获取时间线程启动
    camerwidget_rtc_thread = new CamerWidget_rtc_thread;
    connect(camerwidget_rtc_thread,&CamerWidget_rtc_thread::date_time_sig,this,&CamerWidget::rtc_updata);
    camerwidget_rtc_thread->start();

    //获取天气数据
    url_weather_now = "https://api.seniverse.com/v3/weather/now.json?key=kyccvwzmf1uh8q0g&location=ip&language=zh-Hans&unit=c";
    //url_weather_life = "https://api.seniverse.com/v3/life/suggestion.json?key=kyccvwzmf1uh8q0g&location=ip&language=zh-Hans";
    m_NetManger = new QNetworkAccessManager;
    connect(m_NetManger,&QNetworkAccessManager::finished,this,&CamerWidget::finishedSlot);

    weather_timer = new QTimer(this);
    connect(weather_timer,&QTimer::timeout,this,&CamerWidget::weather_get);
    weather_get();
    weather_timer->start(20000);

    //init system info label
    ui->cpu_info_label->setText("CPU信息 : NULL");
    ui->cpu_temp_label->setText("CPU温度 : NULL");
    ui->mem_info_label->setText("内存信息 : NULL");
    ui->disk_info_label->setText("硬盘信息 : NULL");

    // start camer thread
    QFile cam_dev("/dev/video0");
    if(cam_dev.open(QFile::ReadOnly))
    {
        cam_dev.close();
        camerwidget_camer_thread = new CamerWidget_camer_thread;
        //使用自定义结构体在信号槽中传递时需要先注册，否则会报错
        qRegisterMetaType<CamerInfo_data>("CamerInfo_data");

        connect(camerwidget_camer_thread,&CamerWidget_camer_thread::camer_image_sig,this,&CamerWidget::camer_updata);

        camerwidget_camer_thread->start();
    }
    else
    {
        ui->camer_label->setText("无摄像头设备信息");
        qDebug() << "No file named /dev/video0";
    }

    //close时可以进入析构函数
    this->setAttribute(Qt::WA_DeleteOnClose);
}

CamerWidget::~CamerWidget()
{
    if(camerwidget_rtc_thread->isRunning())
    {
        camerwidget_rtc_thread->stop();
        camerwidget_rtc_thread->wait();
        camerwidget_rtc_thread->quit();
    }
    delete camerwidget_rtc_thread;

    if(camerwidget_camer_thread->isRunning())
    {
        camerwidget_camer_thread->stop();
        camerwidget_camer_thread->wait();
        camerwidget_camer_thread->quit();
    }
    delete camerwidget_camer_thread;

    if(m_NetManger != NULL)
    {
        delete m_NetManger;
    }

    delete ui;
}

void CamerWidget::camer_updata(CamerInfo_data camer_info_data)
{
    ui->camer_label->setPixmap(QPixmap::fromImage(camer_info_data.image).scaled(ui->camer_label->size()));

    //this->update();
}

void CamerWidget::get_cpu_info(CpuInfo_data cpu_info_data)
{
    QString cpu_info_str,cpu_temp_str;
    cpu_info_str = QString("CPU信息 : %1%").arg(QString::number(cpu_info_data.rate, 'f', 2));
    cpu_temp_str = QString("CPU温度 : %1°C").arg(QString::number(cpu_info_data.temp,'f',2));

    ui->cpu_info_label->setText(cpu_info_str);
    ui->cpu_temp_label->setText(cpu_temp_str);
}

void CamerWidget::get_mem_info(MemInfo_data mem_info_data)
{
    QString mem_info_str;
    mem_info_str = QString("内存信息 : %1 / %2 MB    %3%").arg(mem_info_data.used).arg(mem_info_data.total).arg(QString::number(mem_info_data.rate,'f',2));

    ui->mem_info_label->setText(mem_info_str);
}

void CamerWidget::get_disk_info(DiskInfo_data disk_info_data)
{
    QString disk_info_str;
    double total = static_cast<double>((double)disk_info_data.total / 1024);
    double used = static_cast<double>((double)disk_info_data.used / 1024);

    disk_info_str = QString("硬盘信息 : %1 / %2 GB    %3%").arg(QString::number(used,'f',2)).arg(QString::number(total,'f',2)).arg(QString::number(disk_info_data.rate,'f',2));

    ui->disk_info_label->setText(disk_info_str);
}

void CamerWidget::weather_get()
{
    QUrl url(url_weather_now);
    m_NetManger->clearAccessCache();
    m_Reply = m_NetManger->get(QNetworkRequest(url));
}

void CamerWidget::finishedSlot(QNetworkReply *)
{
    m_Reply->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    m_Reply->attribute(QNetworkRequest::RedirectionTargetAttribute);

    if (m_Reply->error() == QNetworkReply::NoError)
    {
        QByteArray bytes = m_Reply->readAll();
        if(!bytes.isNull())
        {
            json_analysis_now(bytes);
            //qDebug() << "weather_updata";
            weather_updata();
        }
    }
    else
    {
        qDebug() << m_Reply->errorString();
    }

    m_Reply->deleteLater();
}

void CamerWidget::rtc_updata(QDateTime date_time)
{
    QString time_text = date_time.toString(tr("MM/dd hh:mm:ss"));
    //QString time_text = date_time.toString(tr("hh:mm:ss"));
    ui->localtime_label->setText(time_text);
    QString week_text = date_time.toString(tr("dddd"));

    if(week_text == "Monday")
    {
        week_text = "星期一";
    }
    else if(week_text == "Tuesday")
    {
        week_text = "星期二";
    }
    else if(week_text == "Wednesday")
    {
        week_text = "星期三";
    }
    else if(week_text == "Thursday")
    {
        week_text = "星期四";
    }
    else if(week_text == "Friday")
    {
        week_text = "星期五";
    }
    else if(week_text == "Saturday")
    {
        week_text = "星期六";
    }
    else if(week_text == "Sunday")
    {
        week_text = "星期日";
    }

    ui->week_label->setText(week_text);
}

void CamerWidget::mousePressEvent(QMouseEvent *event)
{
    int mouse_press_x,mouse_press_y; //鼠标点击时的坐标
    mouse_press_x = event->x();
    mouse_press_y = event->y();

    //qDebug() << QString("press point : (%1,%2)").arg(mouse_press_x).arg(mouse_press_y);

    int weather_widget_startX,weather_widget_startY;
    weather_widget_startX = this->width() - ui->info_weather_widget->width();
    weather_widget_startY = this->height() - ui->info_weather_widget->height();

    //qDebug() << QString("weather widget : (%1,%2)").arg(weather_widget_startX).arg(weather_widget_startY);

    if((mouse_press_x > weather_widget_startX) && (mouse_press_x < this->width()))
    {
        if((mouse_press_y > weather_widget_startY) && (mouse_press_y < this->height()))
        {
            emit mousePress_sig(true);
        }
    }
}

void CamerWidget::camer_widget_stop(bool flag)
{
    if(flag == true)
    {
        //true为停止
        weather_timer->stop();
        camerwidget_rtc_thread->stop();
        //camerwidget_camer_thread->stop();
    }
    else
    {
        //flase为启动
        weather_timer->start(20000);
        camerwidget_rtc_thread->start();
        //camerwidget_camer_thread->start();
    }
}

void CamerWidget::weather_updata()
{
    //显示天气实况
    ui->temp_lcdNumber->display(weather_now_data.temperature);
    ui->path_label->setText(weather_now_data.name);
    ui->weather_text_label->setText(weather_now_data.text);

    //天气图片
    QString weather_ico_path;
    weather_ico_path = "./image/black/" + weather_now_data.code + "@2x.png";
    QPixmap weatherprint(weather_ico_path);
    ui->weather_code_label->setPixmap(weatherprint);
    ui->weather_code_label->setScaledContents(true);
    ui->weather_code_label->show();
}

//获取天气实况的json解析算法
void CamerWidget::json_analysis_now(QByteArray data)
{
    QByteArray block;
    block = data;
    //qDebug() << "接收 : " << block;
    QJsonParseError json_error;
    QJsonDocument parse_doucment = QJsonDocument::fromJson(block, &json_error);

    //qDebug() << "parse_doucment : " << parse_doucment;
    //下面是json格式的解析
    if(json_error.error == QJsonParseError::NoError)
    {
        if(parse_doucment.isObject())
        {
            //开始解析json对象
            QJsonObject jsonObject = parse_doucment.object();
            if(jsonObject.contains("results"))
            {
                QJsonValue results_value = jsonObject.take("results");
                if(results_value.isArray()) //判断他是不是json数组
                {
                    QJsonArray results_array = results_value.toArray();
                    QJsonObject results_object = results_array.at(0).toObject();
                    //qDebug() << "results_object : " << results_object;

                    //提取last_update
                    if(results_object.contains("last_update"))
                    {
                        weather_now_data.last_update = results_object.take("last_update").toString();
                        //qDebug() << "last_update : " << last_update;
                    }

                    //提取location
                    if(results_object.contains("location"))
                    {
                        QJsonValue location_value = results_object.take("location");
                        //qDebug() << "location_value : " << location_value;
                        QJsonObject location_object = location_value.toObject();
                        //提取country
                        if(location_object.contains("country"))
                        {
                            weather_now_data.country = location_object.take("country").toString();
                            //qDebug() << "country : " << country;
                        }
                        //提取id
                        if(location_object.contains("id"))
                        {
                            weather_now_data.id = location_object.take("id").toString();
                            //qDebug() << "id : " << id;
                        }
                        //提取name
                        if(location_object.contains("name"))
                        {
                            weather_now_data.name = location_object.take("name").toString();
                            //qDebug() << "name : " << name;
                        }
                        //提取path
                        if(location_object.contains("path"))
                        {
                            weather_now_data.path = location_object.take("path").toString();
                            //qDebug() << "path : " << path;
                        }
                        //提取timezone
                        if(location_object.contains("timezone"))
                        {
                            weather_now_data.timezone = location_object.take("timezone").toString();
                            //qDebug() << "timezone : " << timezone;
                        }
                        //提取timezone_offset
                        if(location_object.contains("timezone_offset"))
                        {
                            weather_now_data.timezone_offset = location_object.take("timezone_offset").toString();
                            //qDebug() << "timezone_offset : " << timezone_offset;
                        }

                    }

                    //提取now
                    if(results_object.contains("now"))
                    {
                        QJsonValue now_value = results_object.take("now");
                        //qDebug() << "now_value : " << now_value;
                        QJsonObject now_object = now_value.toObject();
                        //提取code
                        if(now_object.contains("code"))
                        {
                            weather_now_data.code = now_object.take("code").toString();
                            //qDebug() << "code : " << code;
                        }
                        //提取temperature
                        if(now_object.contains("temperature"))
                        {
                            weather_now_data.temperature = now_object.take("temperature").toString();
                            //qDebug() << "temperature : " << temperature;
                        }
                        //提取text
                        if(now_object.contains("text"))
                        {
                            weather_now_data.text = now_object.take("text").toString();
                            //qDebug() << "text : " << text;
                        }

                    }
                }
            }
        }
    }
}

