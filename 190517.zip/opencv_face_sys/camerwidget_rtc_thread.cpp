#include "camerwidget_rtc_thread.h"

CamerWidget_rtc_thread::CamerWidget_rtc_thread(QObject *parent) :
    QThread(parent)
{
    stopped = true;
}

CamerWidget_rtc_thread::~CamerWidget_rtc_thread()
{
    stopped = true;
}

void CamerWidget_rtc_thread::run()
{
    stopped = false;

    while(stopped == false)
    {
        date_time = QDateTime::currentDateTime();//获取系统现在的时间
        emit date_time_sig(date_time);
        msleep(500);
    }
}

void CamerWidget_rtc_thread::stop()
{
    stopped = true;
}
