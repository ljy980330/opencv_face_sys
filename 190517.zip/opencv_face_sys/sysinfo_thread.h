#ifndef SYSINFO_THREAD_H
#define SYSINFO_THREAD_H

#include <QObject>
#include "includes.h"

class SysInfo_thread : public QThread
{
    Q_OBJECT
public:
    explicit SysInfo_thread(QObject *parent = 0);
    ~SysInfo_thread();

    void stop();

    void get_cpu_info();
    void get_mem_info();
    void get_disk_info();

    struct CpuInfo_data cpu_info_data;

    struct MemInfo_data mem_info_data;

    struct DiskInfo_data disk_info_data;

protected:
    void run();

signals:
    void cpu_info_sig(struct CpuInfo_data);
    void mem_info_sig(struct MemInfo_data);
    void disk_info_sig(struct DiskInfo_data);

private:
    volatile bool stopped;

};

#endif // SYSINFO_THREAD_H
