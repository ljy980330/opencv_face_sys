#ifndef CAMERWIDGET_RTC_THREAD_H
#define CAMERWIDGET_RTC_THREAD_H

#include <QObject>
#include "includes.h"

class CamerWidget_rtc_thread : public QThread
{
    Q_OBJECT
public:
    explicit CamerWidget_rtc_thread(QObject *parent = 0);
    ~CamerWidget_rtc_thread();

    void stop();

    QDateTime date_time;

protected:
    void run();

signals:
    void date_time_sig(QDateTime data);

public slots:

private:
    volatile bool stopped;
};

#endif // CAMERWIDGET_RTC_THREAD_H
