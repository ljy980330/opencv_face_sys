#include "camerwidget_camer_thread.h"

CamerWidget_camer_thread::CamerWidget_camer_thread(QObject *parent) :
    QThread(parent)
{
    stopped = true;
}

CamerWidget_camer_thread::~CamerWidget_camer_thread()
{
    stopped = true;

    if (capture.isOpened())
    {
        capture.release();
    }
}

void CamerWidget_camer_thread::run()
{
    stopped = false;

    opencam();

    while(stopped == false)
    {
        if (capture.isOpened())
        {
            camer_info_data.fps = capture.get(CV_CAP_PROP_FPS); //get camer fps
            //qDebug() << rate;
            capture >> frame;
            if (!frame.empty())
            {
                camer_info_data.image = Mat2QImage(frame);
                emit camer_image_sig(camer_info_data); //emit image signal
            }
        }
    }
}

void CamerWidget_camer_thread::stop()
{
    stopped = true;

    if (capture.isOpened())
    {
        capture.release();
    }
}

void CamerWidget_camer_thread::opencam()
{
    if (capture.isOpened())
            capture.release();     //decide if capture is already opened; if so,close it
    capture.open(0);           //open the default camera
}

QImage CamerWidget_camer_thread::Mat2QImage(cv::Mat cvImg)
{
    QImage qImg;
    if(cvImg.channels()==3)                             //3 channels color image
    {

        cv::cvtColor(cvImg,cvImg,CV_BGR2RGB);
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols, cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }
    else if(cvImg.channels()==1)                    //grayscale image
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_Indexed8);
    }
    else
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }

    return qImg;
}
