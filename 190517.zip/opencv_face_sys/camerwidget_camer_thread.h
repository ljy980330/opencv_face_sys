#ifndef CAMERWIDGET_CAMER_THREAD_H
#define CAMERWIDGET_CAMER_THREAD_H

#include <QObject>
#include "includes.h"

class CamerWidget_camer_thread : public QThread
{
    Q_OBJECT
public:
    explicit CamerWidget_camer_thread(QObject *parent = 0);
    ~CamerWidget_camer_thread();

    void stop();

    QImage Mat2QImage(cv::Mat cvImg);
    void opencam();
    cv::Mat frame;
    cv::VideoCapture capture;
    struct CamerInfo_data camer_info_data;

public slots:

protected:
    void run();

signals:
    void camer_image_sig(struct CamerInfo_data);

private:
    volatile bool stopped;

};

#endif // CAMERWIDGET_CAMER_THREAD_H
