#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/device.h>
#include <linux/sched.h>
#include <linux/tty.h>

#include <asm/uaccess.h>
#include <asm/irq.h>
#include <asm/io.h>

int major; //���豸��

static struct class *hellodrv_class;
static struct device	*hellodrv_class_dev;

static int hello_drv_open(struct inode *inode, struct file *file)
{
	printk(KERN_EMERG "hello_drv_open\n");
	
	return 0;
}

static ssize_t hello_drv_read(struct file *fd, char __user *buf, size_t count, loff_t *ppos)
{
	printk(KERN_EMERG "hello_drv_read\n");

	return 0;
}

static ssize_t hello_drv_write(struct file *fd, const char __user *buf, size_t count, loff_t *ppos)
{
	printk(KERN_EMERG "hello_drv_write\n");

	return 0;
}

static struct file_operations hello_drv_fops = {
    .owner  =   THIS_MODULE,    /* ����һ���꣬�������ģ��ʱ�Զ�������__this_module���� */
    .open   =   hello_drv_open,
    .read 	=   hello_drv_read,
    .write	=   hello_drv_write,
};

static int hello_drv_init(void)
{
	printk(KERN_EMERG "hello_drv_init...\n");

	major = register_chrdev(0, "hello_drv", &hello_drv_fops); //ע�ᣬ�����ں�
	
	hellodrv_class = class_create(THIS_MODULE, "hellodrv");

	hellodrv_class_dev = device_create(hellodrv_class, NULL, MKDEV(major, 0), NULL, "hello_drv");
	

	return 0;
}

static void hello_drv_exit(void)
{
	printk(KERN_EMERG "hello_drv_exit...\n");

	unregister_chrdev(major, "hello_drv");
	
	device_unregister(hellodrv_class_dev);
	class_destroy(hellodrv_class);
}

module_init(hello_drv_init);
module_exit(hello_drv_exit);

MODULE_LICENSE("GPL");
