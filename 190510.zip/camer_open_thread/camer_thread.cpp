#include "camer_thread.h"

Camer_thread::Camer_thread(QObject *parent) :
    QThread(parent)
{
    stopped = true;
}

Camer_thread::~Camer_thread()
{
    stopped = true;

    if (capture.isOpened())
            capture.release();
}

void Camer_thread::run()
{
    opencam();

    stopped = false;
    qDebug() << "Camer_thread running...";

    while(stopped == false)
    {
        if (capture.isOpened())
        {
            rate = capture.get(CV_CAP_PROP_FPS); //get camer fps
            //qDebug() << rate;
            capture >> frame;
            if (!frame.empty())
            {
                image = Mat2QImage(frame);
                emit camer_image_sig(image, rate); //emit image signal
            }
        }
    }

    //qDebug() << "Camer_thread run ending";
}

void Camer_thread::stop()
{
    stopped = true;

    if (capture.isOpened())
            capture.release();

    qDebug() << "Camer_thread stopping...";
}

void Camer_thread::opencam()
{
    if (capture.isOpened())
            capture.release();     //decide if capture is already opened; if so,close it
    capture.open(0);           //open the default camera
}

QImage Camer_thread::Mat2QImage(cv::Mat cvImg)
{
    QImage qImg;
    if(cvImg.channels()==3)                             //3 channels color image
    {

        cv::cvtColor(cvImg,cvImg,CV_BGR2RGB);
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols, cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }
    else if(cvImg.channels()==1)                    //grayscale image
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_Indexed8);
    }
    else
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }

    return qImg;
}
