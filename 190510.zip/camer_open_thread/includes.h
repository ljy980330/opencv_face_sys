#ifndef INCLUDES_H
#define INCLUDES_H

// include c++ header
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>

// include linux header
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <termios.h>

// include qt header
#include <QDebug>
#include <QTimer>
#include <QThread>
#include <QMessageBox>
#include <QPixmap>
#include <QImage>

// include opencv header
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "videoio.hpp"

#endif // INCLUDES_H
