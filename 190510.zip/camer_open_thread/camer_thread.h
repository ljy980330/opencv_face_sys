#ifndef CAMER_THREAD_H
#define CAMER_THREAD_H

#include <QObject>
#include "includes.h"

class Camer_thread : public QThread
{
    Q_OBJECT
public:
    explicit Camer_thread(QObject *parent = 0);
    ~Camer_thread();

    void stop();

    QImage Mat2QImage(cv::Mat cvImg);
    void opencam();
    cv::Mat frame;
    cv::VideoCapture capture;
    QImage image; //emit image form thread to dialog
    double rate; //FPS
    cv::VideoWriter writer;   //make a video record

protected:
    void run();

signals:
    void camer_image_sig(QImage image, double rate);

private:
    volatile bool stopped;
};

#endif // CAMER_THREAD_H
