#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    camer_thread = new Camer_thread;
    connect(camer_thread,&Camer_thread::camer_image_sig,this,&Dialog::camer_image_get);
}

Dialog::~Dialog()
{
    if(camer_thread->isRunning())
    {
        camer_thread->stop();
    }
    camer_thread->quit();
    camer_thread->wait();

    delete camer_thread;

    delete ui;
}

void Dialog::camer_image_get(QImage image, double rate)
{
    camer_image = image;
    camer_rate = rate;

    ui->camer_label->setPixmap(QPixmap::fromImage(camer_image).scaled(ui->camer_label->size()));
    ui->camer_fps_label->setText(QString("FPS : %1").arg(camer_rate));

    this->update();
}

void Dialog::on_start_button_clicked()
{
    if(!camer_thread->isRunning())
    {
        camer_thread->start();
    }
}

void Dialog::on_save_button_clicked()
{
    QString image_name = "save.png";

    camer_image.save(image_name);
    qDebug() << "camer image save OK!";
}

void Dialog::on_exit_button_clicked()
{
    if(camer_thread->isRunning())
    {
        camer_thread->stop();
    }
}
