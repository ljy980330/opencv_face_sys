#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include "includes.h"

#include "camer_thread.h"

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

    QImage camer_image;
    double camer_rate; //FPS

protected slots:
    void camer_image_get(QImage image, double rate);

private slots:
    void on_start_button_clicked();

    void on_save_button_clicked();

    void on_exit_button_clicked();

private:
    Ui::Dialog *ui;

    Camer_thread *camer_thread;
};

#endif // DIALOG_H
