#include "camerwidget.h"
#include "ui_camerwidget.h"

CamerWidget::CamerWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CamerWidget)
{
    ui->setupUi(this);

    this->resize(800,480);

    //支持Qt中文字库
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));

    //init system info label
    ui->cpu_info_label->setText("CPU信息 : NULL");
    ui->cpu_temp_label->setText("CPU温度 : NULL");
    ui->mem_info_label->setText("内存信息 : NULL");
    ui->disk_info_label->setText("硬盘信息 : NULL");

    //init camer info label
    ui->camer_label->setText("无摄像头设备信息");

    //close时可以进入析构函数
    this->setAttribute(Qt::WA_DeleteOnClose);
}

CamerWidget::~CamerWidget()
{
    delete ui;
}

void CamerWidget::get_camer_info(struct CamerInfo_Data camer_info_data)
{
    QImage image = Mat2QImage(camer_info_data.frame);

    ui->camer_label->setPixmap(QPixmap::fromImage(image).scaled(ui->camer_label->size()));
}

void CamerWidget::get_sys_info(struct SysInfo_Data sys_info_data)
{
    get_cpu_info(sys_info_data.cpu_info_data);
    get_mem_info(sys_info_data.mem_info_data);
    get_disk_info(sys_info_data.disk_info_data);
}

void CamerWidget::get_cpu_info(struct CpuInfo_Data cpu_info_data)
{
    QString cpu_info_str,cpu_temp_str;
    cpu_info_str = QString("CPU信息 : %1%    %2MHz").arg(QString::number(cpu_info_data.rate, 'f', 2)).arg(cpu_info_data.freq);
    cpu_temp_str = QString("CPU温度 : %1°C").arg(QString::number(cpu_info_data.temp,'f',2));

    ui->cpu_info_label->setText(cpu_info_str);
    ui->cpu_temp_label->setText(cpu_temp_str);
}

void CamerWidget::get_mem_info(struct MemInfo_Data mem_info_data)
{
    QString mem_info_str;
    mem_info_str = QString("内存信息 : %1 / %2 MB    %3%").arg(mem_info_data.used).arg(mem_info_data.total).arg(QString::number(mem_info_data.rate,'f',2));

    ui->mem_info_label->setText(mem_info_str);
}

void CamerWidget::get_disk_info(struct DiskInfo_Data disk_info_data)
{
    QString disk_info_str;
    double total = static_cast<double>((double)disk_info_data.total / 1024);
    double used = static_cast<double>((double)disk_info_data.used / 1024);

    disk_info_str = QString("硬盘信息 : %1 / %2 GB    %3%").arg(QString::number(used,'f',2)).arg(QString::number(total,'f',2)).arg(QString::number(disk_info_data.rate,'f',2));

    ui->disk_info_label->setText(disk_info_str);
}

void CamerWidget::rtc_updata(struct RTC_Data rtc_data)
{
    ui->localtime_label->setText(rtc_data.time_text);
    ui->week_label->setText(rtc_data.week);
}

void CamerWidget::mousePressEvent(QMouseEvent *event)
{
    //摄像头图像区域 1
    //人员信息区域 2
    //天气信息区域 3

    int mouse_press_x,mouse_press_y; //鼠标点击时的坐标
    mouse_press_x = event->x();
    mouse_press_y = event->y();

    weather_widget_startX = this->width() - ui->info_weather_widget->width();
    weather_widget_startY = this->height() - ui->info_weather_widget->height();

    if((mouse_press_x > weather_widget_startX) && (mouse_press_x < this->width()))
    {
        if((mouse_press_y > weather_widget_startY) && (mouse_press_y < this->height()))
        {
            emit mousePress_sig(3);
        }
    }
}

void CamerWidget::get_weather_info(Weather_Data weather_data)
{
    weather_now_updata(weather_data.weather_now);
    //qDebug() << "weather_now_updata";
}

void CamerWidget::weather_now_updata(struct Weather_Now_Data weather_now_data)
{
    //显示天气实况
    ui->temp_lcdNumber->display(weather_now_data.temperature);
    ui->path_label->setText(weather_now_data.name);
    ui->weather_text_label->setText(weather_now_data.text);

    //天气图片
    QString weather_ico_path;
    weather_ico_path = "./image/black/" + weather_now_data.code + "@2x.png";
    QPixmap weatherprint(weather_ico_path);
    ui->weather_code_label->setPixmap(weatherprint);
    ui->weather_code_label->setScaledContents(true);
    ui->weather_code_label->show();
}

QImage CamerWidget::Mat2QImage(cv::Mat cvImg)
{
    QImage qImg;
    if(cvImg.channels()==3)                             //3 channels color image
    {

        cv::cvtColor(cvImg,cvImg,CV_BGR2RGB);
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols, cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }
    else if(cvImg.channels()==1)                    //grayscale image
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_Indexed8);
    }
    else
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }

    return qImg;
}
