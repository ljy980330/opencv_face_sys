#include "mainwidget.h"
#include "ui_mainwidget.h"

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    ui->setupUi(this);

    this->resize(600,600);

    faceCascadeName = "/home/project/opencv/test/7/opencv_7/haarcascades/haarcascade_frontalface_alt2.xml";
    eyeCascadeName = "/home/project/opencv/test/7/opencv_7/haarcascades/haarcascade_eye_tree_eyeglasses.xml";

    if(!faceCascade.load(faceCascadeName.toStdString()))
    {
        qDebug() << QString("Error loading %1. Exiting!").arg(faceCascadeName);
        this->close();
    }
    if(!eyeCascade.load(eyeCascadeName.toStdString()))
    {
        qDebug() << QString("Error loading %1. Exiting!").arg(eyeCascadeName);
        this->close();
    }

    QFile file(VIDEO_NAME);
    if(file.open(QFile::ReadOnly))
    {
        capture.open(VIDEO_NAME);

        timer = new QTimer(this);
        connect(timer,&QTimer::timeout,this,&MainWidget::timer_update);
        timer->start(30);
    }
    else
    {
        qDebug() << "can not open " << VIDEO_NAME;
        this->close();
    }

    //close时可以进入析构函数
    this->setAttribute(Qt::WA_DeleteOnClose);
}

MainWidget::~MainWidget()
{
    if(timer->isActive())
        timer->stop();

    delete ui;
}

void MainWidget::timer_update()
{
    capture >> camer_info.frame;

    //cv::imwrite("save.jpg", camer_info.frame);

    if(!camer_info.frame.empty())
    {
        ui->camer_widget_1->setCamerPic(camer_info.frame);
        ui->camer_widget_2->setCamerPic(faceCasePic(camer_info.frame));
        ui->camer_widget_3->setCamerPic(eyeCasePic(camer_info.frame));
    }
}

cv::Mat MainWidget::eyeCasePic(cv::Mat img)
{
    using namespace cv;

    Mat frame, frameGray;
    frame = img;

    //缩放系数
    float scalingFactor = 0.75;
    std::vector<Rect> faces;

    //改变大小
    cv::resize(frame, frame, Size(), scalingFactor, scalingFactor, INTER_AREA);

    //转换灰度
    cvtColor(frame, frameGray, CV_BGR2GRAY);

    //均衡直方图
    equalizeHist(frameGray, frameGray);

    //检测脸部
    faceCascade.detectMultiScale(frameGray, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30,30));

    //在每一个人脸上识别眼睛
    for(std::size_t i=0; i < faces.size(); i++)
    {
        Mat faceROI = frameGray(faces[i]);
        std::vector<Rect> eyes;

        //检测眼睛
        eyeCascade.detectMultiScale(faceROI, eyes, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30,30));

        for(std::size_t j=0; j < eyes.size(); j++)
        {
            Rect eyeRect(faces[i].x+eyes[j].x, faces[i].y+eyes[j].y, eyes[j].width, eyes[j].height);

            rectangle(frame, eyeRect, Scalar(0,255,0), 2, LINE_AA);
        }
    }

    return frame;
}

cv::Mat MainWidget::faceCasePic(cv::Mat img)
{
    using namespace cv;

    Mat frame, frameGray;
    frame = img;

    //缩放系数
    float scalingFactor = 0.75;
    std::vector<Rect> faces;

    //改变大小
    cv::resize(frame, frame, Size(), scalingFactor, scalingFactor, INTER_AREA);

    //转换灰度
    cvtColor(frame, frameGray, CV_BGR2GRAY);

    //均衡直方图
    equalizeHist(frameGray, frameGray);

    //检测脸部
    faceCascade.detectMultiScale(frameGray, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30,30));

    //框出人脸
    for(uint i=0; i < faces.size(); i++)
    {
        Rect feceRect(faces[i].x, faces[i].y, faces[i].width, faces[i].height);

        rectangle(frame, feceRect, Scalar(0,0,255), 2, LINE_AA);
    }

    return frame;
}
