#ifndef CAMERWIDGET_H
#define CAMERWIDGET_H

#include <QWidget>
#include "includes.h"

class CamerWidget : public QWidget
{
    Q_OBJECT
public:
    explicit CamerWidget(QWidget *parent = 0);
    ~CamerWidget();

    QImage image;
    int i = 0;

    void setCamerPic(cv::Mat pic);

protected:
    void paintEvent(QPaintEvent *);
};

#endif // CAMERWIDGET_H
