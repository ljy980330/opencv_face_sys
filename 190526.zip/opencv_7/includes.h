#ifndef INCLUDES_H
#define INCLUDES_H

// include c header
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

// include c++ header
#include <iostream>
#include <string>
#include <cstdio>

// include linux header
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <sys/statfs.h>
#include <sys/vfs.h>

// include qt header
#include <QDebug>
#include <QTimer>
#include <QDateTime>
#include <QThread>
#include <QMessageBox>
#include <QPixmap>
#include <QImage>
#include <QTextCodec>
#include <QPainter>
#include <QPaintEvent>
#include <QBrush>
#include <QPen>
#include <QColor>
#include <QMovie>
#include <QFontDatabase>
#include <QProcess>
#include <QMetaType>

// include opencv header
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "opencv2/objdetect/objdetect.hpp"
#include "videoio.hpp"

// opencv camer info struct
struct CamerInfo_Data
{
    cv::Mat frame;
    double fps;
};

#define VIDEO_NAME "/dev/video0"

static QImage Mat2QImage(cv::Mat cvImg)
{
    QImage qImg;
    if(cvImg.type() == CV_8UC3)                             //3 channels color image
    {
        qImg = QImage(cvImg.data, cvImg.cols, cvImg.rows, cvImg.step, QImage::Format_RGB888);
        return qImg.rgbSwapped();
    }
    else if(cvImg.channels()==1)                    //grayscale image
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_Indexed8);
    }
    else
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }

    return qImg;
}

#endif // INCLUDES_H
