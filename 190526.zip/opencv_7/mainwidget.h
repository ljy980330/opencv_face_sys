#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include "includes.h"

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

    QTimer *timer;

    QString faceCascadeName;
    cv::CascadeClassifier faceCascade;

    QString eyeCascadeName;
    cv::CascadeClassifier eyeCascade;

    cv::VideoCapture capture;
    struct CamerInfo_Data camer_info;

    cv::Mat faceCasePic(cv::Mat img);
    cv::Mat eyeCasePic(cv::Mat img);

public slots:
    void timer_update();

private:
    Ui::MainWidget *ui;
};

#endif // MAINWIDGET_H
