#include "camerwidget.h"

CamerWidget::CamerWidget(QWidget *parent) : QWidget(parent)
{

}

CamerWidget::~CamerWidget()
{

}

void CamerWidget::setCamerPic(cv::Mat pic)
{
    image = Mat2QImage(pic);

    this->update();
}

void CamerWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    if(!image.isNull())
    {
        painter.drawPixmap(0,0,this->width(),this->height(),QPixmap::fromImage(image));
    }
}
