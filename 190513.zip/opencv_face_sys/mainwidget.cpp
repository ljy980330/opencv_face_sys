#include "mainwidget.h"
#include "ui_mainwidget.h"

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    ui->setupUi(this);

    //去除边框
    //this->setWindowFlags(Qt::FramelessWindowHint);

    //初始化背景图片
    BackGroudImage.load(":/image/background1.jpg");

    //支持Qt中文字库
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));

    //初始化中文字库
    int nIndex = QFontDatabase::addApplicationFont("./image/wqy_zenhei.ttf");
    if (nIndex != -1)
    {
        QStringList strList(QFontDatabase::applicationFontFamilies(nIndex));
        if (strList.count() > 0)
        {
            font = QFont(strList.at(0));
            font.setPointSize(20);

            //qDebug() << "set font success!";
        }
    }

    //添加欢迎界面到主界面并显示
    welcome_widget_ui = new WelcomeWidget(this);
    connect(welcome_widget_ui,&WelcomeWidget::welcome_end_sig,this,&MainWidget::camer_widget_setup);

    ui->ui_stackedWidget->addWidget(welcome_widget_ui);
    ui->ui_stackedWidget->setCurrentWidget(welcome_widget_ui);

    //close时可以进入析构函数
    this->setAttribute(Qt::WA_DeleteOnClose);
}

MainWidget::~MainWidget()
{
    //退出程序时要删除的指针，防止内存泄漏
    if(welcome_widget_ui != NULL)
    {
        ui->ui_stackedWidget->removeWidget(welcome_widget_ui);
        delete welcome_widget_ui;
        welcome_widget_ui = NULL;
    }

    if(camer_widget_ui != NULL)
    {
        ui->ui_stackedWidget->removeWidget(camer_widget_ui);
        delete camer_widget_ui;
        camer_widget_ui = NULL;
    }


    delete ui;
}

/***********************************************
 *      Slots functions
 **********************************************/
void MainWidget::camer_widget_setup()
{
    camer_widget_ui = new CamerWidget(this);

    camer_widget_ui->setFont(font);
    ui->ui_stackedWidget->addWidget(camer_widget_ui);
    ui->ui_stackedWidget->setCurrentWidget(camer_widget_ui);

    if(welcome_widget_ui != NULL)
    {
        ui->ui_stackedWidget->removeWidget(welcome_widget_ui);
        delete welcome_widget_ui;
        welcome_widget_ui = NULL;
    }
}


/***********************************************
 *      Event functions
 **********************************************/
void MainWidget::paintEvent(QPaintEvent *)
{
    //重绘界面
    QPainter paint(this);

    //如果背景不为空则填充背景
    if(!BackGroudImage.isNull())
    {
        paint.drawPixmap(QRect(0,0,this->width(),this->height()),BackGroudImage);
    }
}

void MainWidget::resizeEvent(QResizeEvent *)
{

}
