#ifndef CAMERWIDGET_H
#define CAMERWIDGET_H

#include <QWidget>
#include "includes.h"

#include "camerwidget_rtc_thread.h"

namespace Ui {
class CamerWidget;
}

class CamerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CamerWidget(QWidget *parent = 0);
    ~CamerWidget();

    QString url_weather_now;
    //QString url_weather_life;

    QTimer *weather_timer;

    struct Weather_Now_Data
    {
        QString last_update;
        QString country;
        QString id;
        QString name;
        QString path;
        QString timezone;
        QString timezone_offset;
        QString code;
        QString temperature;
        QString text;
    };

    struct Weather_Now_Data weather_now_data;

    void json_analysis_now(QByteArray data);   //解析json格式现在天气

private slots:
    void finishedSlot(QNetworkReply*);

    void weather_get();
    void weather_updata();
    void rtc_updata(QDateTime date_time);

private:
    QNetworkAccessManager *m_NetManger;
    QNetworkReply* m_Reply;

private:
    Ui::CamerWidget *ui;

    CamerWidget_rtc_thread *camerwidget_rtc_thread;
};

#endif // CAMERWIDGET_H
