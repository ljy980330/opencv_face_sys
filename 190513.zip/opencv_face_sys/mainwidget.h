#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include "includes.h"

// include all Widget headers
#include "welcomewidget.h"
#include "camerwidget.h"

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

protected:
    void paintEvent(QPaintEvent *); //界面重绘事件
    void resizeEvent(QResizeEvent *); //窗体大小改变事件

    QPixmap BackGroudImage; //背景图片
    QFont font; //字体

protected slots:
    void camer_widget_setup();

private:
    Ui::MainWidget *ui;

    WelcomeWidget *welcome_widget_ui;
    CamerWidget *camer_widget_ui;
};

#endif // MAINWIDGET_H
