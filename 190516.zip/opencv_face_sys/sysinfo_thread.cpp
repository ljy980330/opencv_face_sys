#include "sysinfo_thread.h"

SysInfo_thread::SysInfo_thread(QObject *parent)
    : QThread(parent)
{
    stopped = true;
}

SysInfo_thread::~SysInfo_thread()
{
    stopped = true;
}

void SysInfo_thread::run()
{
    stopped = false;

    while(stopped == false)
    {
        get_cpu_info();
        get_mem_info();
        get_disk_info();

        QThread::sleep(1);
    }
}

void SysInfo_thread::stop()
{
    stopped = true;
}

//获得CPU信息
void SysInfo_thread::get_cpu_info()
{
    //获得CPU占用信息
    QString info_file_name("/proc/stat");
    QFileInfo file_info(info_file_name);
    //判断文件是否存在
    if(file_info.isFile())
    {
        //提取文件中的数据
        std::FILE *cpu_fd = std::fopen(info_file_name.toLatin1().data(),"r");
        if(std::fscanf(cpu_fd,"cpu  %lld %lld %lld %lld %lld %lld %lld %lld",\
                    &cpu_info_data.usr,&cpu_info_data.nic,&cpu_info_data.sys, \
                    &cpu_info_data.idle,&cpu_info_data.iowait, \
                    &cpu_info_data.irq,&cpu_info_data.softirq, \
                    &cpu_info_data.steal) < 4)
        {
            qDebug() << "failed to read " << info_file_name;
        }
        std::fclose(cpu_fd);

        //计算CPU总资源数
        cpu_info_data.total = cpu_info_data.usr + cpu_info_data.nic + cpu_info_data.sys + cpu_info_data.idle + cpu_info_data.iowait + cpu_info_data.irq + cpu_info_data.softirq + cpu_info_data.steal;

        //获取CPU占用率
        cpu_info_data.rate = static_cast<double>(1.0 - ((double)cpu_info_data.idle/(double)cpu_info_data.total)) * 100.0;

        //qDebug() << QString("cpu usage rate : %1%").arg(QString::number(cpu_info_data.rate, 'f', 2));

    }
    else
    {
        qDebug() << "No file named : " << info_file_name;
        return;
    }

    //获取CPU温度
    QString temp_file_name("/sys/class/thermal/thermal_zone0/temp");
    file_info.setFile(temp_file_name);
    if(file_info.isFile())
    {
        QFile temp_file(temp_file_name);
        if(temp_file.open(QFile::ReadOnly))
        {
            QString cpu_temp_str = temp_file.readAll();
            cpu_info_data.temp = static_cast<double>((double)(cpu_temp_str.toDouble()) / 1000.0);

            //qDebug() << QString("cpu temp : %1°C").arg(QString::number(cpu_info_data.temp,'f',2));
            temp_file.close();
        }
    }
    else
    {
        qDebug() << "No file named : " << temp_file_name;
        return;
    }

    emit cpu_info_sig(cpu_info_data);
}

//获取内存信息
void SysInfo_thread::get_mem_info()
{
    QString file_info_name("/proc/meminfo");
    QFileInfo file_info(file_info_name);
    if(file_info.isFile())
    {
        std::FILE *mem_fd = std::fopen(file_info_name.toLatin1().data(),"r");
        std::fscanf(mem_fd,"MemTotal: %lu kB\n",&mem_info_data.total);
        std::fscanf(mem_fd,"MemFree: %lu kB\n",&mem_info_data.free);
        std::fclose(mem_fd);
        mem_info_data.used = mem_info_data.total - mem_info_data.free;
        mem_info_data.rate = static_cast<double>((double)mem_info_data.used / (double)mem_info_data.total) * 100.0;

        mem_info_data.total = mem_info_data.total / 1024;
        mem_info_data.used  = mem_info_data.used  / 1024;
        mem_info_data.free  = mem_info_data.free  / 1024;

        //qDebug() << QString("Mem : %1 / %2 MB    %3%").arg(mem_info_data.used).arg(mem_info_data.total).arg(QString::number(mem_info_data.rate,'f',2));
    }
    else
    {
        qDebug() << "No file named : " << file_info_name;
        return;
    }

    emit mem_info_sig(mem_info_data);
}

//获取硬盘中根目录使用情况
void SysInfo_thread::get_disk_info()
{
    struct statfs disk_info;
    QString path = "/";

    if (statfs(path.toLatin1().data(), &disk_info) == -1)
    {
        qDebug() << "Failed to get file disk infomation";
        return;
    }

    disk_info_data.total = disk_info.f_blocks * disk_info.f_bsize;
    disk_info_data.free = disk_info.f_bfree * disk_info.f_bsize;
    disk_info_data.used = disk_info_data.total - disk_info_data.free;
    disk_info_data.rate = static_cast<double>((double)disk_info_data.used / (double)disk_info_data.total) * 100.0;

    disk_info_data.total = disk_info_data.total / 1024 / 1024;
    disk_info_data.free  = disk_info_data.free  / 1024 / 1024;
    disk_info_data.used  = disk_info_data.used  / 1024 / 1024;

    //double total = static_cast<double>((double)disk_info_data.total / 1024);
    //double used = static_cast<double>((double)disk_info_data.used / 1024);

    //qDebug() << QString("Disk : %1 / %2 GB    %3%").arg(QString::number(used,'f',2)).arg(QString::number(total,'f',2)).arg(QString::number(disk_info_data.rate,'f',2));

    emit disk_info_sig(disk_info_data);
}

