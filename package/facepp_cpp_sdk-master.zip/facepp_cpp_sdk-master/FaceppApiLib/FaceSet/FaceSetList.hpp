//
//  FaceSetList.hpp
//  FaceppApiLib
//
//  Created by Li Cheng on 2018/9/30.
//  Copyright © 2018年 Li Cheng. All rights reserved.
//

#ifndef FaceSetList_hpp
#define FaceSetList_hpp

#include <stdio.h>

class FaceSetListApi {
public:
    void getFaceSetList(const char *api_key ,const char *api_secret);
};

#endif /* FaceSetList_hpp */
