#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "includes.h"
#include "facefind_thread.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

    QString faceImagePath = "/home/project/opencv/test/face++/opencv_face/face.jpg";

    QString faceFilePath = "/home/project/opencv/test/face++/opencv_face/";

    struct FaceSearchData faceSearch;

    CamerInfo_Data camer_info;
    cv::VideoCapture captrue;

    QString faceCascadeName;
    cv::CascadeClassifier faceCascade;

    cv::Mat faceCasePic(cv::Mat img);

    QTimer *timer;
    QTimer *findFaceDelay_timer;
    QTimer *delay_timer;

    bool delay_flag;
    bool findFace_flag;

public slots:
    void get_face_search(struct FaceSearchData data);

protected slots:
    void timer_update();
    void findFaceDelay_update();
    void delay_update();

private slots:
    void on_start_pushButton_clicked();

    void on_stop_pushButton_clicked();

private:
    Ui::Widget *ui;

    FaceFind_thread *facefind_thread;
};

#endif // WIDGET_H
