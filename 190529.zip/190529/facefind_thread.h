#ifndef FACEFIND_THREAD_H
#define FACEFIND_THREAD_H

#include <QObject>
#include "includes.h"

class FaceFind_thread : public QThread
{
    Q_OBJECT
public:
    explicit FaceFind_thread(QObject *parent = 0);
    ~FaceFind_thread();

    QString faceImagePath = "/home/project/opencv/test/face++/opencv_face/face.jpg";
    const char *APIkey = "换成你自己的";
    const char *APIsecre = "换成你自己的";
    const char *FaceSetToken = "换成你自己的";

    QString apiJsonRet;
    FaceppApi *faceApi;

    struct FaceSearchData faceSearch;

    bool json_analysis(QString str);

signals:
    void face_search_sig(struct FaceSearchData);

protected:
    void run();
};

#endif // FACEFIND_THREAD_H
