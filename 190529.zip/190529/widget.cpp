#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    qRegisterMetaType<FaceSearchData>("FaceSearchData");

    delay_flag = false;
    findFace_flag = false;

    QFile file(VIDEO_NAME);
    if(file.open(QFile::ReadOnly))
    {
        file.close();
        captrue.open(VIDEO_NAME);

        timer = new QTimer(this);
        connect(timer,&QTimer::timeout,this,&Widget::timer_update);
        timer->start(30);
    }
    else
    {
        QMessageBox::warning(this,"Warning!!!","Cmaer can not open!!!",QMessageBox::Yes);
        this->close();
    }

    faceCascadeName = "/home/project/opencv/test/7/opencv_7/haarcascades/haarcascade_frontalface_alt2.xml";

    if(!faceCascade.load(faceCascadeName.toStdString()))
    {
        qDebug() << QString("Error loading %1. Exiting!").arg(faceCascadeName);
        this->close();
    }

    findFaceDelay_timer = new QTimer(this);
    connect(findFaceDelay_timer,&QTimer::timeout,this,&Widget::findFaceDelay_update);

    delay_timer = new QTimer(this);
    connect(delay_timer,&QTimer::timeout,this,&Widget::delay_update);

    facefind_thread = new FaceFind_thread;
    connect(facefind_thread,&FaceFind_thread::face_search_sig,this,&Widget::get_face_search);

    //close时可以进入析构函数
    this->setAttribute(Qt::WA_DeleteOnClose);
}

Widget::~Widget()
{
    if(captrue.isOpened())
        captrue.release();

    if(timer->isActive())
        timer->stop();

    if(facefind_thread->isRunning())
    {
        facefind_thread->wait();
    }
    facefind_thread->quit();
    delete facefind_thread;

    delete ui;
}

void Widget::get_face_search(struct FaceSearchData data)
{
    faceSearch = data;

    if(!faceSearch.error_message.isEmpty())
    {
        QMessageBox::warning(this,"Warning!!!",faceSearch.error_message,QMessageBox::Ok);
        on_stop_pushButton_clicked();
        return;
    }

    ui->label_1->setText(QString("花费时间: %1毫秒").arg(faceSearch.time_used));
    ui->label_2->setText(QString("匹配率: : %1").arg(faceSearch.results.confidence));

    if(faceSearch.results.confidence > faceSearch.thresholds.thresholds_5)
    {
        ui->label_3->setText(QString("结果: 识别成功\n%1").arg(faceSearch.results.face_token));


        QString filePath = faceFilePath+faceSearch.results.face_token+".txt";
        QFileInfo fileInfo(filePath);
        if(!fileInfo.isFile())
        {
            QFile file(filePath);
            if(file.open(QFile::WriteOnly))
            {
                file.close();
            }
        }
        QFile file(filePath);
        if(file.open(QFile::WriteOnly|QFile::Append))
        {
            QDateTime datetime = QDateTime::currentDateTime();
            file.write(datetime.toString("yyyy-MM-dd HH:mm:ss").toLatin1());
            file.write(QString("\n").toLatin1());
            file.close();
            qDebug() << "write OK";
        }
        else
        {
            qDebug() << "write failed...." << filePath;
        }


        delay_timer->setSingleShot(true);
        delay_timer->start(10000);
        delay_flag = true;
    }
    else
    {
        QMessageBox::warning(this,"识别失败","请重试！！！",QMessageBox::Yes);
        delay_update();
    }

    on_stop_pushButton_clicked();
}

void Widget::findFaceDelay_update()
{
    on_start_pushButton_clicked();

    cv::imwrite(faceImagePath.toLatin1().data(), camer_info.frame);

    facefind_thread->start();
}

void Widget::delay_update()
{
    findFace_flag = false;

    delay_flag = false;
}

void Widget::timer_update()
{
    captrue >> camer_info.frame;

    if(delay_flag == false)
        ui->camer_widget->setCamerPic(faceCasePic(camer_info.frame));
    else
        ui->camer_widget->setCamerPic(camer_info.frame);
}

cv::Mat Widget::faceCasePic(cv::Mat img)
{
    using namespace cv;

    Mat frame, frameGray;
    frame = img;

    //缩放系数
    float scalingFactor = 0.75;
    std::vector<Rect> faces;

    //改变大小
    cv::resize(frame, frame, Size(), scalingFactor, scalingFactor, INTER_AREA);

    //转换灰度
    cvtColor(frame, frameGray, CV_BGR2GRAY);

    //均衡直方图
    equalizeHist(frameGray, frameGray);

    //检测脸部
    faceCascade.detectMultiScale(frameGray, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30,30));

    //框出人脸
    if(faces.size() != 1)
        return frame;

    for(uint i=0; i < faces.size(); i++)
    {
        Rect feceRect(faces[i].x, faces[i].y, faces[i].width, faces[i].height);
        rectangle(frame, feceRect, Scalar(0,0,255), 2, LINE_AA);
    }

    if(findFace_flag == false)
    {
        findFace_flag = true;
        findFaceDelay_timer->setSingleShot(true);
        findFaceDelay_timer->start(1000);
    }

    return frame;
}

void Widget::on_start_pushButton_clicked()
{
    if(timer->isActive())
        timer->stop();
    ui->camer_widget->setFindPic(true);

}

void Widget::on_stop_pushButton_clicked()
{
    ui->camer_widget->setFindPic(false);    ui->camer_widget->setFindPic(false);
    if(!timer->isActive())
        timer->start(30);
}
