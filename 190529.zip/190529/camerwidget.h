#ifndef CAMERWIDGET_H
#define CAMERWIDGET_H

#include <QWidget>
#include "includes.h"

class CamerWidget : public QWidget
{
    Q_OBJECT
public:
    explicit CamerWidget(QWidget *parent = 0);
    ~CamerWidget();

    QImage image;
    cv::Mat img;

    int startX,startY;
    int sideWid;

    bool loadFlag;
    QLabel *loadLabel;
    QMovie *loadMovie;

    void setCamerPic(cv::Mat pic);
    void setFindPic(bool flag);

    cv::Mat setBrightness(cv::Mat mat, int BrightValue);

protected:
    void paintEvent(QPaintEvent *);
};

#endif // CAMERWIDGET_H
