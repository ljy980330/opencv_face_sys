#include "camerwidget.h"
#include "ui_camerwidget.h"

CamerWidget::CamerWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CamerWidget)
{
    ui->setupUi(this);

    this->resize(800,480);

    //支持Qt中文字库
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));

    //获取时间线程启动
    camerwidget_rtc_thread = new CamerWidget_rtc_thread;
    connect(camerwidget_rtc_thread,&CamerWidget_rtc_thread::date_time_sig,this,&CamerWidget::rtc_updata);
    camerwidget_rtc_thread->start();

    //获取天气数据
    url_weather_now = "https://api.seniverse.com/v3/weather/now.json?key=kyccvwzmf1uh8q0g&location=ip&language=zh-Hans&unit=c";
    //url_weather_life = "https://api.seniverse.com/v3/life/suggestion.json?key=kyccvwzmf1uh8q0g&location=ip&language=zh-Hans";
    m_NetManger = new QNetworkAccessManager;
    connect(m_NetManger,&QNetworkAccessManager::finished,this,&CamerWidget::finishedSlot);

    weather_timer = new QTimer(this);
    connect(weather_timer,&QTimer::timeout,this,&CamerWidget::weather_get);
    weather_get();
    weather_timer->start(20000);

    //close时可以进入析构函数
    this->setAttribute(Qt::WA_DeleteOnClose);
}

CamerWidget::~CamerWidget()
{
    if(camerwidget_rtc_thread->isRunning())
    {
        camerwidget_rtc_thread->stop();
        camerwidget_rtc_thread->wait();
        camerwidget_rtc_thread->quit();
    }
    delete camerwidget_rtc_thread;

    if(m_NetManger != NULL)
    {
        delete m_NetManger;
    }
    if(m_Reply != NULL)
    {
        delete m_Reply;
    }

    delete ui;
}

void CamerWidget::weather_get()
{
    QUrl url(url_weather_now);
    m_NetManger->clearAccessCache();
    m_Reply = m_NetManger->get(QNetworkRequest(url));
}

void CamerWidget::finishedSlot(QNetworkReply *)
{
    m_Reply->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    m_Reply->attribute(QNetworkRequest::RedirectionTargetAttribute);

    if (m_Reply->error() == QNetworkReply::NoError)
    {
        QByteArray bytes = m_Reply->readAll();
        if(!bytes.isNull())
        {
            json_analysis_now(bytes);
            //qDebug() << "weather_updata";
            weather_updata();
        }
    }
    else
    {
        qDebug() << m_Reply->errorString();
    }

    m_Reply->deleteLater();
}

void CamerWidget::rtc_updata(QDateTime date_time)
{
    QString time_text = date_time.toString(tr("MM/dd hh:mm:ss"));
    //QString time_text = date_time.toString(tr("hh:mm:ss"));
    ui->localtime_label->setText(time_text);
    QString week_text = date_time.toString(tr("dddd"));

    if(week_text == "Monday")
    {
        week_text = "星期一";
    }
    else if(week_text == "Tuesday")
    {
        week_text = "星期二";
    }
    else if(week_text == "Wednesday")
    {
        week_text = "星期三";
    }
    else if(week_text == "Thursday")
    {
        week_text = "星期四";
    }
    else if(week_text == "Friday")
    {
        week_text = "星期五";
    }
    else if(week_text == "Saturday")
    {
        week_text = "星期六";
    }
    else if(week_text == "Sunday")
    {
        week_text = "星期日";
    }

    ui->week_label->setText(week_text);
}

void CamerWidget::mousePressEvent(QMouseEvent *event)
{
    int mouse_press_x,mouse_press_y; //鼠标点击时的坐标
    mouse_press_x = event->x();
    mouse_press_y = event->y();

    //qDebug() << QString("press point : (%1,%2)").arg(mouse_press_x).arg(mouse_press_y);

    int weather_widget_startX,weather_widget_startY;
    weather_widget_startX = this->width() - ui->info_weather_widget->width();
    weather_widget_startY = this->height() - ui->info_weather_widget->height();

    //qDebug() << QString("weather widget : (%1,%2)").arg(weather_widget_startX).arg(weather_widget_startY);

    if((mouse_press_x > weather_widget_startX) && (mouse_press_x < this->width()))
    {
        if((mouse_press_y > weather_widget_startY) && (mouse_press_y < this->height()))
        {
            emit mousePress_sig(true);
        }
    }
}

void CamerWidget::camer_widget_stop(bool flag)
{
    if(flag == true)
    {
        //true为停止
        weather_timer->stop();
        camerwidget_rtc_thread->stop();
    }
    else
    {
        //flase为启动
        weather_timer->start(20000);
        camerwidget_rtc_thread->start();
    }
}

void CamerWidget::weather_updata()
{
    //显示天气实况
    ui->temp_lcdNumber->display(weather_now_data.temperature);
    ui->path_label->setText(weather_now_data.name);
    ui->weather_text_label->setText(weather_now_data.text);

    //天气图片
    QString weather_ico_path;
    weather_ico_path = "./image/black/" + weather_now_data.code + "@2x.png";
    QPixmap weatherprint(weather_ico_path);
    ui->weather_code_label->setPixmap(weatherprint);
    ui->weather_code_label->setScaledContents(true);
    ui->weather_code_label->show();
}

//获取天气实况的json解析算法
void CamerWidget::json_analysis_now(QByteArray data)
{
    QByteArray block;
    block = data;
    //qDebug() << "接收 : " << block;
    QJsonParseError json_error;
    QJsonDocument parse_doucment = QJsonDocument::fromJson(block, &json_error);

    //qDebug() << "parse_doucment : " << parse_doucment;
    //下面是json格式的解析
    if(json_error.error == QJsonParseError::NoError)
    {
        if(parse_doucment.isObject())
        {
            //开始解析json对象
            QJsonObject jsonObject = parse_doucment.object();
            if(jsonObject.contains("results"))
            {
                QJsonValue results_value = jsonObject.take("results");
                if(results_value.isArray()) //判断他是不是json数组
                {
                    QJsonArray results_array = results_value.toArray();
                    QJsonObject results_object = results_array.at(0).toObject();
                    //qDebug() << "results_object : " << results_object;

                    //提取last_update
                    if(results_object.contains("last_update"))
                    {
                        weather_now_data.last_update = results_object.take("last_update").toString();
                        //qDebug() << "last_update : " << last_update;
                    }

                    //提取location
                    if(results_object.contains("location"))
                    {
                        QJsonValue location_value = results_object.take("location");
                        //qDebug() << "location_value : " << location_value;
                        QJsonObject location_object = location_value.toObject();
                        //提取country
                        if(location_object.contains("country"))
                        {
                            weather_now_data.country = location_object.take("country").toString();
                            //qDebug() << "country : " << country;
                        }
                        //提取id
                        if(location_object.contains("id"))
                        {
                            weather_now_data.id = location_object.take("id").toString();
                            //qDebug() << "id : " << id;
                        }
                        //提取name
                        if(location_object.contains("name"))
                        {
                            weather_now_data.name = location_object.take("name").toString();
                            //qDebug() << "name : " << name;
                        }
                        //提取path
                        if(location_object.contains("path"))
                        {
                            weather_now_data.path = location_object.take("path").toString();
                            //qDebug() << "path : " << path;
                        }
                        //提取timezone
                        if(location_object.contains("timezone"))
                        {
                            weather_now_data.timezone = location_object.take("timezone").toString();
                            //qDebug() << "timezone : " << timezone;
                        }
                        //提取timezone_offset
                        if(location_object.contains("timezone_offset"))
                        {
                            weather_now_data.timezone_offset = location_object.take("timezone_offset").toString();
                            //qDebug() << "timezone_offset : " << timezone_offset;
                        }

                    }

                    //提取now
                    if(results_object.contains("now"))
                    {
                        QJsonValue now_value = results_object.take("now");
                        //qDebug() << "now_value : " << now_value;
                        QJsonObject now_object = now_value.toObject();
                        //提取code
                        if(now_object.contains("code"))
                        {
                            weather_now_data.code = now_object.take("code").toString();
                            //qDebug() << "code : " << code;
                        }
                        //提取temperature
                        if(now_object.contains("temperature"))
                        {
                            weather_now_data.temperature = now_object.take("temperature").toString();
                            //qDebug() << "temperature : " << temperature;
                        }
                        //提取text
                        if(now_object.contains("text"))
                        {
                            weather_now_data.text = now_object.take("text").toString();
                            //qDebug() << "text : " << text;
                        }

                    }
                }
            }
        }
    }
}

