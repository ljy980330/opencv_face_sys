#ifndef INCLUDES_H
#define INCLUDES_H

// include c++ header
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>

// include linux header
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <termios.h>

// include qt header
#include <QDebug>
#include <QTimer>
#include <QDateTime>
#include <QThread>
#include <QMessageBox>
#include <QPixmap>
#include <QImage>
#include <QTextCodec>
#include <QPainter>
#include <QPaintEvent>
#include <QMovie>
#include <QFontDatabase>
#include <QtNetwork>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonValue>

// include opencv header
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "videoio.hpp"

struct Weather_Now_Data
{
    QString last_update;
    QString country;
    QString id;
    QString name;
    QString path;
    QString timezone;
    QString timezone_offset;
    QString code;
    QString temperature;
    QString text;
};

struct Weather_Life_Data
{
    QString car_washing; //洗车
    QString dressing; //穿衣
    QString flu; //感冒
    QString sport; //运动
    QString travel; //旅游
    QString uv; //紫外线
};

struct Weather_Daily_Data
{
    QString date; //返回日期
    QString text_day; //白天天气现象文字
    QString code_day; //白天天气现象代码
    QString text_night; //晚间天气现象文字
    QString code_night; //晚间天气现象代码
    QString high; //当天最高温度
    QString low; //当天最低温度
    QString precip; //降水概率 范围0~100，单位百分比
    QString wind_direction; //风向文字
    QString wind_direction_degree; //风向角度 范围0~360
    QString wind_speed; //风速，单位km/h
    QString wind_scale; //风力等级
};

#endif // INCLUDES_H
