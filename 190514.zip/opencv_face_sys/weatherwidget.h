#ifndef WEATHERWIDGET_H
#define WEATHERWIDGET_H

#include <QWidget>
#include "includes.h"

#include "camerwidget_rtc_thread.h"

namespace Ui {
class WeatherWidget;
}

class WeatherWidget : public QWidget
{
    Q_OBJECT

public:
    explicit WeatherWidget(QWidget *parent = 0);
    ~WeatherWidget();

    QString url_weather_now;
    QString url_weather_daily;
    QString url_weather_life;

    struct Weather_Now_Data weather_now;
    struct Weather_Daily_Data weather_daily_1, weather_daily_2, weather_daily_3;
    struct Weather_Life_Data weather_life;

    void json_analysis_now(QByteArray data);   //解析json格式现在天气
    void json_analysis_daliy(QByteArray data); //解析json格式逐日时间
    void json_analysis_life(QByteArray data);  //解析json格式生活指数

signals:
    void weather_widget_close_sig();

protected:
    void mousePressEvent(QMouseEvent *);

protected slots:
    void weather_updata();

private slots:
    void finishedSlot_now(QNetworkReply*);
    void finishedSlot_daily(QNetworkReply*);
    void finishedSlot_life(QNetworkReply*);

    void rtc_updata(QDateTime date_time);

private:
    Ui::WeatherWidget *ui;

    QNetworkAccessManager *m_NetManger_now;
    QNetworkAccessManager *m_NetManger_daily;
    QNetworkAccessManager *m_NetManger_life;

    QNetworkReply *m_Reply_now;
    QNetworkReply *m_Reply_daily;
    QNetworkReply *m_Reply_life;

    CamerWidget_rtc_thread *weatherwidget_rtc_thread;
};

#endif // WEATHERWIDGET_H
