#include "weatherwidget.h"
#include "ui_weatherwidget.h"

WeatherWidget::WeatherWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WeatherWidget)
{
    ui->setupUi(this);

    this->resize(800,480);

    //获取时间线程启动
    weatherwidget_rtc_thread = new CamerWidget_rtc_thread;
    connect(weatherwidget_rtc_thread,&CamerWidget_rtc_thread::date_time_sig,this,&WeatherWidget::rtc_updata);
    weatherwidget_rtc_thread->start();

    //获取天气数据
    url_weather_now = "https://api.seniverse.com/v3/weather/now.json?key=换成你自己的&location=ip&language=zh-Hans&unit=c";
    url_weather_daily = "https://api.seniverse.com/v3/weather/daily.json?key=换成你自己的&location=ip&language=zh-Hans&unit=c&start=0&days=5";
    url_weather_life = "https://api.seniverse.com/v3/life/suggestion.json?key=换成你自己的&location=ip&language=zh-Hans";

    m_NetManger_now = new QNetworkAccessManager;
    m_NetManger_daily = new QNetworkAccessManager;
    m_NetManger_life = new QNetworkAccessManager;

    connect(m_NetManger_now,&QNetworkAccessManager::finished,this,&WeatherWidget::finishedSlot_now);
    connect(m_NetManger_daily,&QNetworkAccessManager::finished,this,&WeatherWidget::finishedSlot_daily);
    connect(m_NetManger_life,&QNetworkAccessManager::finished,this,&WeatherWidget::finishedSlot_life);

    m_Reply_now = m_NetManger_now->get(QNetworkRequest(url_weather_now));
    m_Reply_life = m_NetManger_life->get(QNetworkRequest(url_weather_life));
    m_Reply_daily = m_NetManger_daily->get(QNetworkRequest(url_weather_daily));

    //close时可以进入析构函数
    this->setAttribute(Qt::WA_DeleteOnClose);
}

WeatherWidget::~WeatherWidget()
{
    //qDebug() << "~WeatherWidget start...";
    if(weatherwidget_rtc_thread->isRunning())
    {
        weatherwidget_rtc_thread->stop();
        weatherwidget_rtc_thread->wait();
        weatherwidget_rtc_thread->quit();
    }
    delete weatherwidget_rtc_thread;

    if(m_NetManger_now != NULL)
    {
        delete m_NetManger_now;
    }
    if(m_NetManger_daily != NULL)
    {
        delete m_NetManger_daily;
    }
    if(m_NetManger_life != NULL)
    {
        delete m_NetManger_life;
    }

    delete ui;
}

void WeatherWidget::finishedSlot_now(QNetworkReply *)
{
    m_Reply_now->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    m_Reply_now->attribute(QNetworkRequest::RedirectionTargetAttribute);

    if (m_Reply_now->error() == QNetworkReply::NoError)
    {
        QByteArray bytes = m_Reply_now->readAll();
        //QString data = QString::fromUtf8(bytes);
        //qDebug() << "m_Reply_now: " << data;
        json_analysis_now(bytes);
        weather_updata();
    }
    else
    {
        qDebug() << m_Reply_now->errorString();
    }

    m_Reply_now->deleteLater();
}

void WeatherWidget::finishedSlot_life(QNetworkReply *)
{
    m_Reply_life->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    m_Reply_life->attribute(QNetworkRequest::RedirectionTargetAttribute);

    if (m_Reply_life->error() == QNetworkReply::NoError)
    {
        QByteArray bytes = m_Reply_life->readAll();
        //QString data = QString::fromUtf8(bytes);
        //qDebug() << "m_Reply_life: " << data;
        json_analysis_life(bytes);
        weather_updata();
    }
    else
    {
        qDebug() << m_Reply_life->errorString();
    }

    m_Reply_life->deleteLater();
}

void WeatherWidget::finishedSlot_daily(QNetworkReply *)
{
    m_Reply_daily->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    m_Reply_daily->attribute(QNetworkRequest::RedirectionTargetAttribute);

    if (m_Reply_daily->error() == QNetworkReply::NoError)
    {
        QByteArray bytes = m_Reply_daily->readAll();
        //QString data = QString::fromUtf8(bytes);
        //qDebug() << "m_Reply_daily: " << data;
        json_analysis_daliy(bytes);
        weather_updata();
    }
    else
    {
        qDebug() << m_Reply_daily->errorString();
    }

    m_Reply_daily->deleteLater();
}

void WeatherWidget::weather_updata()
{
    //显示天气实况
    ui->temp_lcdNumber_2->display(weather_now.temperature);
    ui->path_label_2->setText(weather_now.name);
    ui->weather_text_label_2->setText(weather_now.text);

    weather_now.last_update.replace(10,1,' ');
    weather_now.last_update.replace(19,6,' ');
    ui->last_updata_label->setText(tr("最后更新时间：%1").arg(weather_now.last_update));
    //天气图片
    QString weather_ico_path;
    weather_ico_path = "./image/black/" + weather_now.code + "@2x.png";
    QPixmap weatherprint(weather_ico_path);
    ui->weather_code_label_2->setPixmap(weatherprint);
    ui->weather_code_label_2->setScaledContents(true);
    ui->weather_code_label_2->show();

    //今天
    ui->daily_today_text_label->setText(weather_daily_1.text_day);
    ui->daily_today_label->setText(weather_daily_1.date);
    ui->daily_today_temp_label->setText(tr("温度：%1/%2").arg(weather_daily_1.high).arg(weather_daily_1.low));
    ui->daily_today_wind_direction_label->setText(tr("风向：%1").arg(weather_daily_1.wind_direction));
    ui->daily_today_wind_speed_label->setText(tr("风力：%1级").arg(weather_daily_1.wind_scale));
    //天气图片
    QString today_weather_ico_path;
    today_weather_ico_path = "./image/black/" + weather_daily_1.code_day + "@2x.png";
    QPixmap today_weatherprint(today_weather_ico_path);
    ui->daily_today_code_label->setPixmap(today_weatherprint);
    ui->daily_today_code_label->setScaledContents(true);
    ui->daily_today_code_label->show();

    //明天
    ui->daily_tomorrow_text_label->setText(weather_daily_2.text_day);
    ui->daily_tomorrow_label->setText(weather_daily_2.date);
    ui->daily_tomorrow_temp_label->setText(tr("温度：%1/%2").arg(weather_daily_2.high).arg(weather_daily_2.low));
    ui->daily_tomorrow_wind_direction_label->setAlignment(Qt::AlignHCenter);
    ui->daily_tomorrow_wind_direction_label->setText(tr("风向：%1").arg(weather_daily_2.wind_direction));
    ui->daily_tomorrow_wind_speed_label->setText(tr("风力：%1级").arg(weather_daily_2.wind_scale));
    //天气图片
    QString tomorrow_weather_ico_path;
    tomorrow_weather_ico_path = "./image/black/" + weather_daily_2.code_day + "@2x.png";
    QPixmap tomorrow_weatherprint(tomorrow_weather_ico_path);
    ui->daily_tomorrow_code_label->setPixmap(tomorrow_weatherprint);
    ui->daily_tomorrow_code_label->setScaledContents(true);
    ui->daily_tomorrow_code_label->show();

    //后天
    ui->daily_the_day_after_text_label_2->setText(weather_daily_2.text_day);
    ui->daily_the_day_after_label->setText(weather_daily_2.date);
    ui->daily_the_day_after_temp_label_2->setText(tr("温度：%1/%2").arg(weather_daily_2.high).arg(weather_daily_2.low));
    ui->daily_the_day_after_wind_direction_label_2->setText(tr("风向：%1").arg(weather_daily_2.wind_direction));
    ui->daily_the_day_after_wind_speed_label_2->setText(tr("风力：%1级").arg(weather_daily_2.wind_scale));
    //天气图片
    QString the_day_after_weather_ico_path;
    the_day_after_weather_ico_path = "./image/black/" + weather_daily_2.code_day + "@2x.png";
    QPixmap the_day_after_weatherprint(the_day_after_weather_ico_path);
    ui->daily_the_day_after_code_label_2->setPixmap(the_day_after_weatherprint);
    ui->daily_the_day_after_code_label_2->setScaledContents(true);
    ui->daily_the_day_after_code_label_2->show();

    //生活指数
    ui->car_washing_label->setText(tr("洗车：%1").arg(weather_life.car_washing));
    ui->dressing_label->setText(tr("穿衣：%1").arg(weather_life.dressing));
    ui->flu_label->setText(tr("感冒：%1").arg(weather_life.flu));
    ui->sport_label->setText(tr("运动：%1").arg(weather_life.sport));
    ui->travel_label->setText(tr("旅游：%1").arg(weather_life.travel));
    ui->uv_label->setText(tr("紫外线：%1").arg(weather_life.uv));
}

void WeatherWidget::rtc_updata(QDateTime date_time)
{
    QString time_text = date_time.toString(tr("hh:mm:ss"));
    //qDebug() << time_text;
    ui->localtime_label_2->setText(time_text);
    QString week_text = date_time.toString(tr("dddd"));

    if(week_text == "Monday")
    {
        week_text = "星期一";
    }
    else if(week_text == "Tuesday")
    {
        week_text = "星期二";
    }
    else if(week_text == "Wednesday")
    {
        week_text = "星期三";
    }
    else if(week_text == "Thursday")
    {
        week_text = "星期四";
    }
    else if(week_text == "Friday")
    {
        week_text = "星期五";
    }
    else if(week_text == "Saturday")
    {
        week_text = "星期六";
    }
    else if(week_text == "Sunday")
    {
        week_text = "星期日";
    }

    ui->week_label_2->setText(week_text);
}

void WeatherWidget::mousePressEvent(QMouseEvent *)
{
    //qDebug() << "weather_widget_close_sig";
    emit weather_widget_close_sig();
}

void WeatherWidget::json_analysis_now(QByteArray data)
{
    QByteArray block;
    block = data;
    //qDebug() << "接收 : " << block;
    QJsonParseError json_error;
    QJsonDocument parse_doucment = QJsonDocument::fromJson(block, &json_error);

    //qDebug() << "parse_doucment : " << parse_doucment;
    //下面是json格式的解析
    if(json_error.error == QJsonParseError::NoError)
    {
        if(parse_doucment.isObject())
        {
            //开始解析json对象
            QJsonObject jsonObject = parse_doucment.object();
            if(jsonObject.contains("results"))
            {
                QJsonValue results_value = jsonObject.take("results");
                if(results_value.isArray()) //判断他是不是json数组
                {
                    QJsonArray results_array = results_value.toArray();
                    QJsonObject results_object = results_array.at(0).toObject();
                    //qDebug() << "results_object : " << results_object;

                    //提取last_update
                    if(results_object.contains("last_update"))
                    {
                        weather_now.last_update = results_object.take("last_update").toString();
                        //qDebug() << "last_update : " << last_update;
                    }

                    //提取location
                    if(results_object.contains("location"))
                    {
                        QJsonValue location_value = results_object.take("location");
                        //qDebug() << "location_value : " << location_value;
                        QJsonObject location_object = location_value.toObject();
                        //提取country
                        if(location_object.contains("country"))
                        {
                            weather_now.country = location_object.take("country").toString();
                            //qDebug() << "country : " << country;
                        }
                        //提取id
                        if(location_object.contains("id"))
                        {
                            weather_now.id = location_object.take("id").toString();
                            //qDebug() << "id : " << id;
                        }
                        //提取name
                        if(location_object.contains("name"))
                        {
                            weather_now.name = location_object.take("name").toString();
                            //qDebug() << "name : " << name;
                        }
                        //提取path
                        if(location_object.contains("path"))
                        {
                            weather_now.path = location_object.take("path").toString();
                            //qDebug() << "path : " << path;
                        }
                        //提取timezone
                        if(location_object.contains("timezone"))
                        {
                            weather_now.timezone = location_object.take("timezone").toString();
                            //qDebug() << "timezone : " << timezone;
                        }
                        //提取timezone_offset
                        if(location_object.contains("timezone_offset"))
                        {
                            weather_now.timezone_offset = location_object.take("timezone_offset").toString();
                            //qDebug() << "timezone_offset : " << timezone_offset;
                        }

                    }

                    //提取now
                    if(results_object.contains("now"))
                    {
                        QJsonValue now_value = results_object.take("now");
                        //qDebug() << "now_value : " << now_value;
                        QJsonObject now_object = now_value.toObject();
                        //提取code
                        if(now_object.contains("code"))
                        {
                            weather_now.code = now_object.take("code").toString();
                            //qDebug() << "code : " << code;
                        }
                        //提取temperature
                        if(now_object.contains("temperature"))
                        {
                            weather_now.temperature = now_object.take("temperature").toString();
                            //qDebug() << "temperature : " << temperature;
                        }
                        //提取text
                        if(now_object.contains("text"))
                        {
                            weather_now.text = now_object.take("text").toString();
                            //qDebug() << "text : " << text;
                        }

                    }
                }
            }
        }
    }
}

void WeatherWidget::json_analysis_daliy(QByteArray data)
{
    QByteArray block;
    block = data;
    //qDebug() << "接收 : " << block;
    QJsonParseError json_error;
    QJsonDocument parse_doucment = QJsonDocument::fromJson(block, &json_error);

    //qDebug() << "parse_doucment : " << parse_doucment;

    if(json_error.error == QJsonParseError::NoError)
    {
        if(parse_doucment.isObject())
        {
            //开始解析json对象
            QJsonObject jsonObject = parse_doucment.object();
            if(jsonObject.contains("results"))
            {
                QJsonValue results_value = jsonObject.take("results");
                if(results_value.isArray()) //判断他是不是json数组
                {
                    QJsonArray results_array = results_value.toArray();
                    QJsonObject results_object = results_array.at(0).toObject();
                    //qDebug() << "results_object : " << results_object;

                    //提取daily
                    if(results_object.contains("daily"))
                    {
                        QJsonValue daily_value = results_object.take("daily");
                        if(daily_value.isArray()) //判断是不是json数组
                        {
                            //分别提取今天，明天，后天的天气预报
                            QJsonArray daily_array = daily_value.toArray();
                            QJsonObject today_object = daily_array.at(0).toObject();
                            QJsonObject tomorrow_object = daily_array.at(1).toObject();
                            QJsonObject the_day_after_tomorrow_object = daily_array.at(2).toObject();

                            //提取今天的date
                            if(today_object.contains("date"))
                            {
                                weather_daily_1.date = today_object.take("date").toString();
                                //qDebug() << "today date : " << weather_daily_1.date;
                            }
                            //提取今天的code_day
                            if(today_object.contains("code_day"))
                            {
                                weather_daily_1.code_day = today_object.take("code_day").toString();
                                //qDebug() << "today code_day : " << weather_daily_1.code_day;
                            }
                            //提取今天的code_night
                            if(today_object.contains("code_night"))
                            {
                                weather_daily_1.code_night = today_object.take("code_night").toString();
                                //qDebug() << "today code_night : " << weather_daily_1.code_night;
                            }
                            //提取今天的high
                            if(today_object.contains("high"))
                            {
                                weather_daily_1.high = today_object.take("high").toString();
                                //qDebug() << "today high : " << weather_daily_1.high;
                            }
                            //提取今天的low
                            if(today_object.contains("low"))
                            {
                                weather_daily_1.low = today_object.take("low").toString();
                                //qDebug() << "today low : " << weather_daily_1.low;
                            }
                            //提取今天的precip
                            if(today_object.contains("precip"))
                            {
                                weather_daily_1.precip = today_object.take("precip").toString();
                                //qDebug() << "today precip : " << weather_daily_1.precip;
                            }
                            //提取今天的text_day
                            if(today_object.contains("text_day"))
                            {
                                weather_daily_1.text_day = today_object.take("text_day").toString();
                                //qDebug() << "today text_day : " << weather_daily_1.text_day;
                            }
                            //提取今天的text_night
                            if(today_object.contains("text_night"))
                            {
                                weather_daily_1.text_night = today_object.take("text_night").toString();
                                //qDebug() << "today text_night : " << weather_daily_1.text_night;
                            }
                            //提取今天的wind_direction
                            if(today_object.contains("wind_direction"))
                            {
                                weather_daily_1.wind_direction = today_object.take("wind_direction").toString();
                                //qDebug() << "today wind_direction : " << weather_daily_1.wind_direction;
                            }
                            //提取今天的wind_direction_degree
                            if(today_object.contains("wind_direction_degree"))
                            {
                                weather_daily_1.wind_direction_degree = today_object.take("wind_direction_degree").toString();
                                //qDebug() << "today wind_direction_degree : " << weather_daily_1.wind_direction_degree;
                            }
                            //提取今天的wind_scale
                            if(today_object.contains("wind_scale"))
                            {
                                weather_daily_1.wind_scale = today_object.take("wind_scale").toString();
                                //qDebug() << "today wind_scale : " << weather_daily_1.wind_scale;
                            }
                            //提取今天的wind_speed
                            if(today_object.contains("wind_speed"))
                            {
                                weather_daily_1.wind_speed = today_object.take("wind_speed").toString();
                                //qDebug() << "today wind_speed : " << weather_daily_1.wind_speed;
                            }

                            //提取明天的date
                            if(tomorrow_object.contains("date"))
                            {
                                weather_daily_2.date = tomorrow_object.take("date").toString();
                                //qDebug() << "tomorrow date : " << weather_daily_2.date;
                            }
                            //提取明天的code_day
                            if(tomorrow_object.contains("code_day"))
                            {
                                weather_daily_2.code_day = tomorrow_object.take("code_day").toString();
                                //qDebug() << "tomorrow code_day : " << weather_daily_2.code_day;
                            }
                            //提取明天的code_night
                            if(tomorrow_object.contains("code_night"))
                            {
                                weather_daily_2.code_night = tomorrow_object.take("code_night").toString();
                                //qDebug() << "tomorrow code_night : " << weather_daily_2.code_night;
                            }
                            //提取明天的high
                            if(tomorrow_object.contains("high"))
                            {
                                weather_daily_2.high = tomorrow_object.take("high").toString();
                                //qDebug() << "tomorrow high : " << weather_daily_2.high;
                            }
                            //提取明天的low
                            if(tomorrow_object.contains("low"))
                            {
                                weather_daily_2.low = tomorrow_object.take("low").toString();
                                //qDebug() << "tomorrow low : " << weather_daily_2.low;
                            }
                            //提取明天的precip
                            if(tomorrow_object.contains("precip"))
                            {
                                weather_daily_2.precip = tomorrow_object.take("precip").toString();
                                //qDebug() << "tomorrow precip : " << weather_daily_2.precip;
                            }
                            //提取明天的text_day
                            if(tomorrow_object.contains("text_day"))
                            {
                                weather_daily_2.text_day = tomorrow_object.take("text_day").toString();
                                //qDebug() << "tomorrow text_day : " << weather_daily_2.text_day;
                            }
                            //提取明天的text_night
                            if(tomorrow_object.contains("text_night"))
                            {
                                weather_daily_2.text_night = tomorrow_object.take("text_night").toString();
                                //qDebug() << "tomorrow text_night : " << weather_daily_2.text_night;
                            }
                            //提取明天的wind_direction
                            if(tomorrow_object.contains("wind_direction"))
                            {
                                weather_daily_2.wind_direction = tomorrow_object.take("wind_direction").toString();
                                //qDebug() << "tomorrow wind_direction : " << weather_daily_2.wind_direction;
                            }
                            //提取明天的wind_direction_degree
                            if(tomorrow_object.contains("wind_direction_degree"))
                            {
                                weather_daily_2.wind_direction_degree = tomorrow_object.take("wind_direction_degree").toString();
                                //qDebug() << "tomorrow wind_direction_degree : " << weather_daily_2.wind_direction_degree;
                            }
                            //提取明天的wind_scale
                            if(tomorrow_object.contains("wind_scale"))
                            {
                                weather_daily_2.wind_scale = tomorrow_object.take("wind_scale").toString();
                                //qDebug() << "tomorrow wind_scale : " << weather_daily_2.wind_scale;
                            }
                            //提取明天的wind_speed
                            if(tomorrow_object.contains("wind_speed"))
                            {
                                weather_daily_2.wind_speed = tomorrow_object.take("wind_speed").toString();
                                //qDebug() << "tomorrow wind_speed : " << weather_daily_2.wind_speed;
                            }

                            //提取后天的date
                            if(the_day_after_tomorrow_object.contains("date"))
                            {
                                weather_daily_3.date = the_day_after_tomorrow_object.take("date").toString();
                                //qDebug() << "the_day_after_tomorrow date : " << weather_daily_3.date;
                            }
                            //提取后天的code_day
                            if(the_day_after_tomorrow_object.contains("code_day"))
                            {
                                weather_daily_3.code_day = the_day_after_tomorrow_object.take("code_day").toString();
                                //qDebug() << "the_day_after_tomorrow code_day : " << weather_daily_3.code_day;
                            }
                            //提取后天的code_night
                            if(the_day_after_tomorrow_object.contains("code_night"))
                            {
                                weather_daily_3.code_night = the_day_after_tomorrow_object.take("code_night").toString();
                                //qDebug() << "the_day_after_tomorrow code_night : " << weather_daily_3.code_night;
                            }
                            //提取后天的high
                            if(the_day_after_tomorrow_object.contains("high"))
                            {
                                weather_daily_3.high = the_day_after_tomorrow_object.take("high").toString();
                                //qDebug() << "the_day_after_tomorrow high : " << weather_daily_3.high;
                            }
                            //提取后天的low
                            if(the_day_after_tomorrow_object.contains("low"))
                            {
                                weather_daily_3.low = the_day_after_tomorrow_object.take("low").toString();
                                //qDebug() << "the_day_after_tomorrow low : " << weather_daily_3.low;
                            }
                            //提取后天的precip
                            if(the_day_after_tomorrow_object.contains("precip"))
                            {
                                weather_daily_3.precip = the_day_after_tomorrow_object.take("precip").toString();
                                //qDebug() << "the_day_after_tomorrow precip : " << weather_daily_3.precip;
                            }
                            //提取后天的text_day
                            if(the_day_after_tomorrow_object.contains("text_day"))
                            {
                                weather_daily_3.text_day = the_day_after_tomorrow_object.take("text_day").toString();
                                //qDebug() << "the_day_after_tomorrow text_day : " << weather_daily_3.text_day;
                            }
                            //提取后天的text_night
                            if(the_day_after_tomorrow_object.contains("text_night"))
                            {
                                weather_daily_3.text_night = the_day_after_tomorrow_object.take("text_night").toString();
                                //qDebug() << "the_day_after_tomorrow text_night : " << weather_daily_3.text_night;
                            }
                            //提取后天的wind_direction
                            if(the_day_after_tomorrow_object.contains("wind_direction"))
                            {
                                weather_daily_3.wind_direction = the_day_after_tomorrow_object.take("wind_direction").toString();
                                //qDebug() << "the_day_after_tomorrow wind_direction : " << weather_daily_3.wind_direction;
                            }
                            //提取后天的wind_direction_degree
                            if(the_day_after_tomorrow_object.contains("wind_direction_degree"))
                            {
                                weather_daily_3.wind_direction_degree = the_day_after_tomorrow_object.take("wind_direction_degree").toString();
                                //qDebug() << "the_day_after_tomorrow wind_direction_degree : " << weather_daily_3.wind_direction_degree;
                            }
                            //提取后天的wind_scale
                            if(the_day_after_tomorrow_object.contains("wind_scale"))
                            {
                                weather_daily_3.wind_scale = the_day_after_tomorrow_object.take("wind_scale").toString();
                                //qDebug() << "the_day_after_tomorrow wind_scale : " << weather_daily_3.wind_scale;
                            }
                            //提取后天的wind_speed
                            if(the_day_after_tomorrow_object.contains("wind_speed"))
                            {
                                weather_daily_3.wind_speed = the_day_after_tomorrow_object.take("wind_speed").toString();
                                //qDebug() << "the_day_after_tomorrow wind_speed : " << weather_daily_3.wind_speed;
                            }

                        }
                    }
                    //提取last_update
                    if(results_object.contains("last_update"))
                    {
                        //last_update = results_object.take("last_update").toString();
                        //qDebug() << "last_update : " << last_update;
                    }
                    //提取location
                    if(results_object.contains("location"))
                    {
                        QJsonValue location_value = results_object.take("location");
                        //qDebug() << "location_value : " << location_value;
                        QJsonObject location_object = location_value.toObject();
                        //提取country
                        if(location_object.contains("country"))
                        {
                            weather_now.country = location_object.take("country").toString();
                            //qDebug() << "country : " << country;
                        }
                        //提取id
                        if(location_object.contains("id"))
                        {
                            weather_now.id = location_object.take("id").toString();
                            //qDebug() << "id : " << id;
                        }
                        //提取name
                        if(location_object.contains("name"))
                        {
                            weather_now.name = location_object.take("name").toString();
                            //qDebug() << "name : " << name;
                        }
                        //提取path
                        if(location_object.contains("path"))
                        {
                            weather_now.path = location_object.take("path").toString();
                            //qDebug() << "path : " << path;
                        }
                        //提取timezone
                        if(location_object.contains("timezone"))
                        {
                            weather_now.timezone = location_object.take("timezone").toString();
                            //qDebug() << "timezone : " << timezone;
                        }
                        //提取timezone_offset
                        if(location_object.contains("timezone_offset"))
                        {
                            weather_now.timezone_offset = location_object.take("timezone_offset").toString();
                            //qDebug() << "timezone_offset : " << timezone_offset;
                        }
                    }
                }
            }
        }
    }
}

void WeatherWidget::json_analysis_life(QByteArray data)
{
    QByteArray block;
    block = data;
    //qDebug() << "接收 : " << block;
    QJsonParseError json_error;
    QJsonDocument parse_doucment = QJsonDocument::fromJson(block, &json_error);

    //qDebug() << "parse_doucment : " << parse_doucment;
    if(json_error.error == QJsonParseError::NoError)
    {
        if(parse_doucment.isObject())
        {
            //开始解析json对象
            QJsonObject jsonObject = parse_doucment.object();
            if(jsonObject.contains("results"))
            {
                QJsonValue results_value = jsonObject.take("results");
                if(results_value.isArray()) //判断他是不是json数组
                {
                    QJsonArray results_array = results_value.toArray();
                    QJsonObject results_object = results_array.at(0).toObject();
                    //qDebug() << "results_object : " << results_object;

                    //提取suggestion
                    if(results_object.contains("suggestion"))
                    {
                        QJsonValue suggestion_value = results_object.take("suggestion");
                        //qDebug() << "suggestion_value : " << suggestion_value;
                        QJsonObject suggestion_object = suggestion_value.toObject();
                        //提取car_washing
                        if(suggestion_object.contains("car_washing"))
                        {
                            QJsonValue car_washing_value = suggestion_object.take("car_washing");
                            QJsonObject car_washing_object = car_washing_value.toObject();
                            if(car_washing_object.contains("brief"))
                            {
                                weather_life.car_washing = car_washing_object.take("brief").toString();
                                //qDebug() << "car_washing : " << car_washing;
                            }
                        }
                        //提取dressing
                        if(suggestion_object.contains("dressing"))
                        {
                            QJsonValue dressing_value = suggestion_object.take("dressing");
                            QJsonObject dressing_object = dressing_value.toObject();
                            if(dressing_object.contains("brief"))
                            {
                                weather_life.dressing = dressing_object.take("brief").toString();
                                //qDebug() << "dressing : " << dressing;
                            }
                        }
                        //提取flu
                        if(suggestion_object.contains("flu"))
                        {
                            QJsonValue flu_value = suggestion_object.take("flu");
                            QJsonObject flu_object = flu_value.toObject();
                            if(flu_object.contains("brief"))
                            {
                                weather_life.flu = flu_object.take("brief").toString();
                                //qDebug() << "flu : " << flu;
                            }
                        }
                        //提取sport
                        if(suggestion_object.contains("sport"))
                        {
                            QJsonValue sport_value = suggestion_object.take("sport");
                            QJsonObject sport_object = sport_value.toObject();
                            if(sport_object.contains("brief"))
                            {
                                weather_life.sport = sport_object.take("brief").toString();
                                //qDebug() << "sport : " << sport;
                            }
                        }
                        //提取travel
                        if(suggestion_object.contains("travel"))
                        {
                            QJsonValue travel_value = suggestion_object.take("travel");
                            QJsonObject travel_object = travel_value.toObject();
                            if(travel_object.contains("brief"))
                            {
                                weather_life.travel = travel_object.take("brief").toString();
                                //qDebug() << "travel : " << travel;
                            }
                        }
                        //uv
                        if(suggestion_object.contains("uv"))
                        {
                            QJsonValue uv_value = suggestion_object.take("uv");
                            QJsonObject uv_object = uv_value.toObject();
                            if(uv_object.contains("brief"))
                            {
                                weather_life.uv = uv_object.take("brief").toString();
                                //qDebug() << "uv : " << uv;
                            }
                        }
                    }
                }
            }
        }
    }
}
